import React from 'react';
import {View, Text, Button} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';


const NetInfo = (): React.JSX.Element => {
  const navigation = useNavigation<NativeStackNavigationProp<any>>();
  return (
    <View>
      <Text>Hello NetInfo</Text>
      <Button title="go back" onPress={() => navigation.goBack()} />
      <Button title="go to Svg" onPress={() => navigation.navigate('Svg')} />
    </View>
  );
};

export default NetInfo;
